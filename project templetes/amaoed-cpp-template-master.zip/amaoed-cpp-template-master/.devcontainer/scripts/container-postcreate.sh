#!/bin/sh

# Verify GCC is installed
gcc --version
